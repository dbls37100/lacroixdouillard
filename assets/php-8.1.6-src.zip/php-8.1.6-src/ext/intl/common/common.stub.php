<?php

/** @generate-class-entries */

class IntlIterator implements Iterator
{
    /** @tentative-return-type */
    public function current(): mixed {}

    /** @tentative-return-type */
    public function key(): mixed {}

    /** @tentative-return-type */
    public function next(): void {}

    /** @tentative-return-type */
    public function rewind(): void {}

    /** @tentative-return-type */
    public function valid(): bool {}
}
