<?php

/** @generate-class-entries */

class IntlPartsIterator extends IntlIterator
{
    /** @tentative-return-type */
    public function getBreakIterator(): IntlBreakIterator {}

    /** @tentative-return-type */
    public function getRuleStatus(): int {}
}
